import React from 'react'

const Artists = () => {
  return (
    <>
      Top Artists
    </>
  )
}

export default Artists
